from ast import If
from zeep import Client
#crear el cliente
cliente = Client('http://localhost:8080/ServicioWeb_SOAP/WSOperaciones?WSDL')

# Login
if cliente.service.Login("Pavel","Paval12020"):
    print('credenciales correctas')
else:
    print('credenciales incorrectas')

# Procesar pago
if cliente.service.ProcesarPago(5000,10000)>=0:
    print('pago realizado')
else:
    print('Dinero insuficiente')