﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
internal class Program
{
    private static void Main(string[] args)
    {
        //crear el cliente
        ServicioWebSOAP.WSOperacionesClient Cliente = new ServicioWebSOAP.WSOperacionesClient();

        //utilizamos los metodos

        //1. login

        if (Cliente.Login("Pavol", "ffoof"))
        {
            Console.WriteLine("Credenciales correctas");
        }
        else
        {
            Console.WriteLine("credenciales incorrectas");
        }
        //procesar pago
        if (Cliente.ProcesarPago(5000,200)>=0)
        {
            Console.WriteLine("Pago realizado");
        }
        else
        {
            Console.WriteLine("Dinero insuficiente");
        }

        //cerramos conexion
        Cliente.Close();
        Console.ReadKey();
    }
}