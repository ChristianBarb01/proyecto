<?php

//Creamos el cliente
$cliente = new SoapClient('http://localhost:8080/ServicioWeb_SOAP/WSOperaciones?WSDL');

//Utilizamos el metodo Procesar Pago
$resultado_pago = $cliente->ProcesarPago([
 "total" =>1000,
 "pago" =>20000   
])->return;
if($resultado_pago>=0){
    echo "Pago Realizado, su vuelto es $resultado_pago";
}else{
    echo 'Dinero insuficiente';
}
